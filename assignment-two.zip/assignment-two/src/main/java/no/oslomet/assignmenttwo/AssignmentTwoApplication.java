package no.oslomet.assignmenttwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentTwoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AssignmentTwoApplication.class, args);
    }

}

